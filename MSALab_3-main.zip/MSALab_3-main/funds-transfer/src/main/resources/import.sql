INSERT INTO account(id, number, balance) VALUES (1,'1111',50000);
INSERT INTO account(id, number, balance) VALUES (2,'2222',10000);
