package com.latambank.loi.repository;

import com.latambank.loi.entity.LetterOfIntent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LetterOfIntentRepository extends JpaRepository<LetterOfIntent, Long> {}
