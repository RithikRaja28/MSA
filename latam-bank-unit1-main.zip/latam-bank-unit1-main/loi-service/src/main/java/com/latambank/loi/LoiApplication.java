package com.latambank.loi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoiApplication {
    public static void main(String[] args) {
        SpringApplication.run(LoiApplication.class, args);
    }
}
